function imprimir(){

window.print();

}
